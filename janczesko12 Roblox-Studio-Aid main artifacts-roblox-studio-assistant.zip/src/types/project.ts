export interface ProjectItem {
  [key: string]: any;
}

export interface Project {
  id: string;
  user_id: string;
  title: string;
  is_favorite: boolean;
  game_idea: ProjectItem | null;
  quest: ProjectItem | null;
  npc: ProjectItem | null;
  gamepass: ProjectItem | null;
  building: ProjectItem | null;
  lua_script: ProjectItem | null;
  created_at: string;
  updated_at: string;
}

export type ProjectField = "game_idea" | "quest" | "npc" | "gamepass" | "building" | "lua_script";

export interface ProjectFieldMeta {
  key: ProjectField;
  label: string;
  icon: string;
}

export const PROJECT_FIELDS: ProjectFieldMeta[] = [
  { key: "game_idea",   label: "Game Idea",   icon: "🎮" },
  { key: "quest",       label: "Quest",       icon: "⚔️" },
  { key: "npc",         label: "NPC",         icon: "🤖" },
  { key: "gamepass",    label: "Gamepass",    icon: "💎" },
  { key: "building",    label: "Building",    icon: "🏗️" },
  { key: "lua_script",  label: "Lua Script",  icon: "📜" },
];
