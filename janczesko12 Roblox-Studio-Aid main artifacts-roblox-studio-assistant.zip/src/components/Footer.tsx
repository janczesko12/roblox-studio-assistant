import { Gamepad2 } from "lucide-react";

export default function Footer() {
  return (
    <footer className="w-full border-t border-border/40 bg-background py-8 mt-16">
      <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Gamepad2 className="w-5 h-5 text-primary" />
          <span className="font-bold text-foreground">Roblox Studio Assistant</span>
        </div>
        <p className="text-sm text-muted-foreground">
          Built for Roblox Developers
        </p>
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <a href="#" className="hover:text-primary transition-colors">GitHub</a>
          <a href="#" className="hover:text-primary transition-colors">Documentation</a>
        </div>
      </div>
      <div className="container mx-auto px-4 mt-8 text-center text-xs text-muted-foreground/50">
        &copy; {new Date().getFullYear()} Roblox Studio Assistant. Not affiliated with Roblox Corporation.
      </div>
    </footer>
  );
}