import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { RefreshCw, Clipboard, Check, Sparkles, Code2, BookmarkPlus } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import SaveToProjectDialog from "@/components/SaveToProjectDialog";

interface LuaCardProps {
  id: string;
  scripts: { title: string; code: string }[];
  delay?: number;
  onResultChange?: (result: any) => void;
  externalResult?: any;
}

export default function LuaCard({ id, scripts, delay = 0, onResultChange, externalResult }: LuaCardProps) {
  const { user } = useAuth();
  const [result, setResult] = useState<{ title: string; code: string } | null>(null);
  const [copied, setCopied] = useState(false);
  const [saveOpen, setSaveOpen] = useState(false);

  useEffect(() => {
    if (externalResult != null) {
      setResult(externalResult);
    }
  }, [externalResult]);

  const handleGenerate = () => {
    const randomScript = scripts[Math.floor(Math.random() * scripts.length)];
    setResult(randomScript);
    setCopied(false);
    onResultChange?.(randomScript);
  };

  const handleCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(result.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.5, delay }}
        id={id}
        className="scroll-mt-24"
      >
        <Card className="border-border bg-card shadow-lg hover:border-primary/20 transition-colors">
          <CardHeader className="flex flex-row items-center justify-between pb-4 space-y-0">
            <CardTitle className="text-xl font-bold flex items-center gap-2">
              <span className="text-primary"><Code2 /></span>
              Lua Script Helper
            </CardTitle>
            <Button onClick={handleGenerate} className="gap-2 font-bold" size="sm">
              <RefreshCw className="w-4 h-4" /> Generate Script
            </Button>
          </CardHeader>

          <CardContent>
            <div className="min-h-[250px] flex flex-col bg-background/50 rounded-md border border-border/50 p-4 relative overflow-hidden">
              <AnimatePresence mode="wait">
                {result ? (
                  <motion.div
                    key="result"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.3 }}
                    className="flex-1 w-full max-w-full overflow-hidden"
                  >
                    <h3 className="font-bold text-lg mb-4 text-foreground">{result.title}</h3>

                    <div className="relative group rounded-md border border-border bg-[#0d0d0d] border-l-4 border-l-primary overflow-x-auto">
                      <pre className="p-4 text-sm font-mono text-muted-foreground whitespace-pre overflow-x-auto">
                        <code>{result.code}</code>
                      </pre>
                    </div>

                    <div className="absolute top-4 right-4 flex gap-1.5">
                      {user && (
                        <Button
                          data-testid="button-save-lua"
                          variant="secondary"
                          size="icon"
                          onClick={() => setSaveOpen(true)}
                          title="Save to project"
                          className="h-8 w-8 bg-background/80 backdrop-blur hover:bg-primary/20 hover:text-primary"
                        >
                          <BookmarkPlus className="w-4 h-4" />
                        </Button>
                      )}
                      <Button
                        variant="secondary"
                        size="icon"
                        onClick={handleCopy}
                        className="h-8 w-8 bg-background/80 backdrop-blur hover:bg-muted"
                      >
                        {copied ? <Check className="w-4 h-4 text-green-500" /> : <Clipboard className="w-4 h-4" />}
                      </Button>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="empty"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex-1 flex flex-col items-center justify-center text-muted-foreground opacity-50"
                  >
                    <Sparkles className="w-12 h-12 mb-4 text-border" />
                    <p>Click Generate to get a Lua snippet</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {result && (
        <SaveToProjectDialog
          open={saveOpen}
          onOpenChange={setSaveOpen}
          field="lua_script"
          data={result}
          fieldLabel="Lua Script"
        />
      )}
    </>
  );
}
