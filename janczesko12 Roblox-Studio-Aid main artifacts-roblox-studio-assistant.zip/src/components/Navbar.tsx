import { useState } from "react";
import { useLocation } from "wouter";
import { Menu, X, Gamepad2, LogIn, LogOut, UserPlus, User, FolderOpen, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/context/AuthContext";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [, setLocation] = useLocation();
  const { user, signOut } = useAuth();

  const links = [
    { name: "Game Ideas", href: "#game-ideas" },
    { name: "Quests", href: "#quests" },
    { name: "NPCs", href: "#npcs" },
    { name: "Gamepasses", href: "#gamepasses" },
    { name: "Buildings", href: "#buildings" },
    { name: "Lua Helper", href: "#lua-helper" },
  ];

  const scrollTo = (id: string) => {
    setIsOpen(false);
    const element = document.querySelector(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleSignOut = async () => {
    setIsOpen(false);
    await signOut();
    setLocation("/");
  };

  const navigate = (path: string) => {
    setIsOpen(false);
    setLocation(path);
  };

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between mx-auto px-4">

        {/* Logo */}
        <button
          data-testid="link-home"
          onClick={() => setLocation("/")}
          className="flex items-center gap-2 font-bold text-lg md:text-xl text-foreground hover:opacity-90 transition-opacity"
        >
          <Gamepad2 className="w-6 h-6 text-primary" />
          <span>Roblox Studio Assistant</span>
        </button>

        {/* Desktop Nav Links */}
        <div className="hidden md:flex items-center gap-6">
          {links.map((link) => (
            <button
              key={link.name}
              onClick={() => scrollTo(link.href)}
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
            >
              {link.name}
            </button>
          ))}
        </div>

        {/* Right side: Avatar + Mobile Toggle */}
        <div className="flex items-center gap-3">

          {/* Avatar Dropdown — always visible */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                data-testid="button-avatar"
                className="relative flex items-center justify-center w-10 h-10 rounded-full bg-secondary border border-border text-muted-foreground transition-all duration-200 hover:border-primary hover:text-primary hover:shadow-[0_0_12px_rgba(224,32,32,0.4)] focus:outline-none focus:ring-2 focus:ring-primary/50"
                aria-label="User menu"
              >
                <User className="w-5 h-5" />
                {user && (
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-green-500 border-2 border-background" />
                )}
              </button>
            </DropdownMenuTrigger>

            <DropdownMenuContent
              align="end"
              className="w-52 bg-card border-border text-foreground shadow-lg shadow-black/40"
            >
              {user ? (
                <>
                  <div className="px-3 py-2 border-b border-border mb-1">
                    <p className="text-xs text-muted-foreground">Signed in as</p>
                    <p className="text-sm font-medium text-foreground truncate">{user.email}</p>
                  </div>

                  <DropdownMenuItem
                    data-testid="dropdown-account"
                    onClick={() => navigate("/account")}
                    className="cursor-pointer gap-2 hover:bg-secondary hover:text-primary focus:bg-secondary focus:text-primary"
                  >
                    <User className="w-4 h-4" />
                    My Account
                  </DropdownMenuItem>

                  <DropdownMenuItem
                    data-testid="dropdown-projects"
                    onClick={() => navigate("/projects")}
                    className="cursor-pointer gap-2 hover:bg-secondary hover:text-primary focus:bg-secondary focus:text-primary"
                  >
                    <FolderOpen className="w-4 h-4" />
                    My Projects
                  </DropdownMenuItem>

                  <DropdownMenuItem
                    data-testid="dropdown-settings"
                    onClick={() => navigate("/settings")}
                    className="cursor-pointer gap-2 hover:bg-secondary hover:text-primary focus:bg-secondary focus:text-primary"
                  >
                    <Settings className="w-4 h-4" />
                    Settings
                  </DropdownMenuItem>

                  <DropdownMenuSeparator className="bg-border" />

                  <DropdownMenuItem
                    data-testid="dropdown-signout"
                    onClick={handleSignOut}
                    className="cursor-pointer gap-2 text-primary hover:bg-primary/10 focus:bg-primary/10 focus:text-primary"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </DropdownMenuItem>
                </>
              ) : (
                <>
                  <DropdownMenuItem
                    data-testid="dropdown-signin"
                    onClick={() => navigate("/login")}
                    className="cursor-pointer gap-2 hover:bg-secondary hover:text-primary focus:bg-secondary focus:text-primary"
                  >
                    <LogIn className="w-4 h-4" />
                    Sign In
                  </DropdownMenuItem>

                  <DropdownMenuItem
                    data-testid="dropdown-register"
                    onClick={() => navigate("/register")}
                    className="cursor-pointer gap-2 hover:bg-secondary hover:text-primary focus:bg-secondary focus:text-primary"
                  >
                    <UserPlus className="w-4 h-4" />
                    Register
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Mobile Nav Toggle */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-foreground"
            onClick={() => setIsOpen(!isOpen)}
            data-testid="button-menu-toggle"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </Button>
        </div>
      </div>

      {/* Mobile Nav Menu */}
      {isOpen && (
        <div className="md:hidden border-t border-border bg-background">
          <div className="flex flex-col space-y-4 px-4 py-6">
            {links.map((link) => (
              <button
                key={link.name}
                onClick={() => scrollTo(link.href)}
                className="text-left text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
              >
                {link.name}
              </button>
            ))}

            <div className="pt-2 border-t border-border space-y-2">
              {user ? (
                <>
                  <p className="text-xs text-muted-foreground px-1 truncate">{user.email}</p>
                  <button
                    data-testid="link-account-mobile"
                    onClick={() => navigate("/account")}
                    className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors w-full py-1"
                  >
                    <User className="w-4 h-4" />
                    My Account
                  </button>
                  <button
                    data-testid="link-projects-mobile"
                    onClick={() => navigate("/projects")}
                    className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors w-full py-1"
                  >
                    <FolderOpen className="w-4 h-4" />
                    My Projects
                  </button>
                  <button
                    data-testid="link-settings-mobile"
                    onClick={() => navigate("/settings")}
                    className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors w-full py-1"
                  >
                    <Settings className="w-4 h-4" />
                    Settings
                  </button>
                  <Button
                    data-testid="button-logout-mobile"
                    variant="outline"
                    size="sm"
                    onClick={handleSignOut}
                    className="w-full border-border text-primary hover:bg-primary/10 gap-1"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </Button>
                </>
              ) : (
                <div className="flex gap-2">
                  <Button
                    data-testid="button-login-mobile"
                    variant="outline"
                    size="sm"
                    onClick={() => navigate("/login")}
                    className="flex-1 border-border text-foreground hover:bg-secondary gap-1"
                  >
                    <LogIn className="w-4 h-4" />
                    Sign In
                  </Button>
                  <Button
                    data-testid="button-register-mobile"
                    size="sm"
                    onClick={() => navigate("/register")}
                    className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground gap-1"
                  >
                    <UserPlus className="w-4 h-4" />
                    Register
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
