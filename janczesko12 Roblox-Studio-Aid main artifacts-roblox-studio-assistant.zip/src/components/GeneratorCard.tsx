import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { RefreshCw, Clipboard, Check, Sparkles, BookmarkPlus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/context/AuthContext";
import SaveToProjectDialog from "@/components/SaveToProjectDialog";
import type { ProjectField } from "@/types/project";

interface GeneratorCardProps {
  id: string;
  title: string;
  icon: React.ReactNode;
  generateFunction: () => any;
  renderResult: (data: any) => React.ReactNode;
  delay?: number;
  projectField: ProjectField;
  fieldLabel: string;
  onResultChange?: (result: any) => void;
  externalResult?: any;
}

export default function GeneratorCard({
  id,
  title,
  icon,
  generateFunction,
  renderResult,
  delay = 0,
  projectField,
  fieldLabel,
  onResultChange,
  externalResult,
}: GeneratorCardProps) {
  const { user } = useAuth();
  const [result, setResult] = useState<any>(null);
  const [copied, setCopied] = useState(false);
  const [saveOpen, setSaveOpen] = useState(false);

  useEffect(() => {
    if (externalResult != null) {
      setResult(externalResult);
    }
  }, [externalResult]);

  const handleGenerate = () => {
    const next = generateFunction();
    setResult(next);
    setCopied(false);
    onResultChange?.(next);
  };

  const handleCopy = () => {
    if (!result) return;
    let textToCopy = "";
    if (typeof result === "object") {
      textToCopy = Object.entries(result)
        .map(([key, val]) => {
          if (Array.isArray(val)) return `${key}: ${val.join(", ")}`;
          return `${key}: ${val}`;
        })
        .join("\n");
    } else {
      textToCopy = String(result);
    }
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.5, delay }}
        id={id}
        className="scroll-mt-24"
      >
        <Card className="border-border bg-card shadow-lg hover:border-primary/20 transition-colors">
          <CardHeader className="flex flex-row items-center justify-between pb-4 space-y-0">
            <CardTitle className="text-xl font-bold flex items-center gap-2">
              <span className="text-primary">{icon}</span>
              {title}
            </CardTitle>
            <Button onClick={handleGenerate} className="gap-2 font-bold" size="sm">
              <RefreshCw className="w-4 h-4" /> Generate
            </Button>
          </CardHeader>

          <CardContent>
            <div className="min-h-[200px] flex flex-col bg-background/50 rounded-md border border-border/50 p-4 relative overflow-hidden">
              <AnimatePresence mode="wait">
                {result ? (
                  <motion.div
                    key="result"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.3 }}
                    className="flex-1"
                  >
                    {renderResult(result)}

                    <div className="absolute top-4 right-4 flex gap-1.5">
                      {user && (
                        <Button
                          data-testid={`button-save-${id}`}
                          variant="secondary"
                          size="icon"
                          onClick={() => setSaveOpen(true)}
                          title="Save to project"
                          className="h-8 w-8 bg-background/80 backdrop-blur hover:bg-primary/20 hover:text-primary"
                        >
                          <BookmarkPlus className="w-4 h-4" />
                        </Button>
                      )}
                      <Button
                        variant="secondary"
                        size="icon"
                        onClick={handleCopy}
                        className="h-8 w-8 bg-background/80 backdrop-blur hover:bg-muted"
                      >
                        {copied ? <Check className="w-4 h-4 text-green-500" /> : <Clipboard className="w-4 h-4" />}
                      </Button>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="empty"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex-1 flex flex-col items-center justify-center text-muted-foreground opacity-50"
                  >
                    <Sparkles className="w-12 h-12 mb-4 text-border" />
                    <p>Click Generate to spark an idea</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {result && (
        <SaveToProjectDialog
          open={saveOpen}
          onOpenChange={setSaveOpen}
          field={projectField}
          data={result}
          fieldLabel={fieldLabel}
        />
      )}
    </>
  );
}
