import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export default function Hero() {
  const scrollToFirst = () => {
    const el = document.querySelector("#game-ideas");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  const scrollToAll = () => {
    scrollToFirst();
  };

  return (
    <section className="relative w-full overflow-hidden border-b border-border/40 py-24 md:py-32">
      {/* Animated subtle grid/particles background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#333_1px,transparent_1px),linear-gradient(to_bottom,#333_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-20" />
      </div>

      <div className="container relative z-10 mx-auto px-4 flex flex-col items-center text-center">
        <motion.h1 
          className="text-4xl md:text-6xl font-extrabold tracking-tight text-foreground max-w-4xl"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Your <span className="text-primary">Roblox Studio</span> Toolkit
        </motion.h1>

        <motion.p 
          className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          Generate game ideas, quests, NPCs, gamepasses, buildings, and Lua scripts instantly — no AI required.
        </motion.p>

        <motion.div 
          className="mt-10 flex flex-col sm:flex-row gap-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Button size="lg" onClick={scrollToFirst} className="font-bold px-8 font-sans">
            Start Creating
          </Button>
          <Button size="lg" variant="outline" onClick={scrollToAll} className="font-bold px-8">
            View All Tools
          </Button>
        </motion.div>
      </div>
    </section>
  );
}