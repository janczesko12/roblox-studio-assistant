import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import {
  Save, Gamepad2, Sword, Bot, Gem, Building2, Code2,
  LogIn, Loader2, FolderOpen, Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { saveFullProject } from "@/lib/projectsApi";

interface Results {
  game_idea: any;
  quest: any;
  npc: any;
  gamepass: any;
  building: any;
  lua_script: any;
}

interface SaveProjectSectionProps {
  results: Results;
}

const FIELDS = [
  { key: "game_idea",  label: "Game Idea",  Icon: Gamepad2 },
  { key: "quest",      label: "Quest",      Icon: Sword    },
  { key: "npc",        label: "NPC",        Icon: Bot      },
  { key: "gamepass",   label: "Gamepass",   Icon: Gem      },
  { key: "building",   label: "Building",   Icon: Building2},
  { key: "lua_script", label: "Lua Script", Icon: Code2    },
] as const;

export default function SaveProjectSection({ results }: SaveProjectSectionProps) {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [projectTitle, setProjectTitle] = useState("");

  const filledCount = FIELDS.filter((f) => results[f.key]).length;
  const hasAny = filledCount > 0;

  const defaultTitle = () => {
    if (results.game_idea?.Title) return results.game_idea.Title;
    return `My Roblox Project — ${new Date().toLocaleDateString("en-US", { month: "short", day: "numeric" })}`;
  };

  const handleSave = async () => {
    if (!user) { setLocation("/login"); return; }
    const title = projectTitle.trim() || defaultTitle();
    setSaving(true);
    try {
      const project = await saveFullProject(user.id, title, {
        game_idea:  results.game_idea  || null,
        quest:      results.quest      || null,
        npc:        results.npc        || null,
        gamepass:   results.gamepass   || null,
        building:   results.building   || null,
        lua_script: results.lua_script || null,
      });
      toast({
        title: "Project saved!",
        description: `"${project.title}" is now in My Projects.`,
      });
      setTimeout(() => setLocation("/projects"), 800);
    } catch (e: any) {
      toast({ title: "Save failed", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <motion.section
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.6 }}
      className="scroll-mt-24"
      id="save-project"
    >
      {/* Glassmorphism card */}
      <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-gradient-to-br from-white/5 via-white/[0.03] to-transparent backdrop-blur-md shadow-2xl shadow-black/40">
        {/* Red glow top-right */}
        <div className="pointer-events-none absolute -top-24 -right-24 w-72 h-72 rounded-full bg-primary/20 blur-3xl" />
        {/* Red glow bottom-left */}
        <div className="pointer-events-none absolute -bottom-16 -left-16 w-56 h-56 rounded-full bg-primary/10 blur-3xl" />

        <div className="relative z-10 p-8 md:p-12">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center">
                  <motion.div
                    animate={{ rotate: saving ? 360 : 0 }}
                    transition={{ duration: 1, repeat: saving ? Infinity : 0, ease: "linear" }}
                  >
                    <Save className="w-6 h-6 text-primary" />
                  </motion.div>
                </div>
                <h2 className="text-3xl font-bold text-foreground">Save Project</h2>
              </div>
              <p className="text-muted-foreground max-w-md">
                Save your generated Roblox game project to your account and access it anytime from My Projects.
              </p>
            </div>

            {/* Content summary */}
            <div className="flex flex-wrap gap-2">
              {FIELDS.map(({ key, label, Icon }) => (
                <Badge
                  key={key}
                  variant="outline"
                  className={`gap-1.5 text-xs transition-all duration-300 ${
                    results[key]
                      ? "border-primary/50 bg-primary/10 text-primary"
                      : "border-border/30 bg-background/30 text-muted-foreground/50"
                  }`}
                >
                  <Icon className="w-3 h-3" />
                  {label}
                </Badge>
              ))}
            </div>
          </div>

          {/* Content */}
          {!user ? (
            /* Logged-out state */
            <div className="flex flex-col sm:flex-row items-center gap-4 p-6 rounded-xl border border-border/40 bg-background/30">
              <div className="flex-1 text-center sm:text-left">
                <p className="font-semibold text-foreground mb-1">Sign in to save projects</p>
                <p className="text-sm text-muted-foreground">
                  Create a free account to save and manage your generated game content.
                </p>
              </div>
              <Button
                data-testid="button-save-signin"
                onClick={() => setLocation("/login")}
                className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2 shrink-0"
              >
                <LogIn className="w-4 h-4" />
                Sign In to Save
              </Button>
            </div>
          ) : !hasAny ? (
            /* Nothing generated yet */
            <div className="flex flex-col items-center gap-3 py-8 text-center text-muted-foreground">
              <Sparkles className="w-10 h-10 text-border" />
              <p className="font-medium">Generate some content first</p>
              <p className="text-sm">Use the generators above to create game ideas, quests, NPCs, and more — then save them all here.</p>
            </div>
          ) : (
            /* Logged-in with content */
            <div className="space-y-5">
              {/* Summary row */}
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <FolderOpen className="w-4 h-4 text-primary" />
                <span>
                  <span className="text-foreground font-medium">{filledCount}</span> of 6 sections ready to save
                </span>
              </div>

              {/* Project title input */}
              <div className="space-y-1.5">
                <Label className="text-foreground text-sm">Project Name</Label>
                <Input
                  data-testid="input-project-title"
                  placeholder={defaultTitle()}
                  value={projectTitle}
                  onChange={(e) => setProjectTitle(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSave()}
                  className="bg-background/50 border-border/60 text-foreground placeholder:text-muted-foreground/60 max-w-md backdrop-blur"
                />
              </div>

              {/* Save button */}
              <motion.div whileTap={{ scale: 0.97 }}>
                <Button
                  data-testid="button-save-project"
                  onClick={handleSave}
                  disabled={saving}
                  size="lg"
                  className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold text-base px-8 gap-3 shadow-lg shadow-primary/25 transition-all duration-200 hover:shadow-primary/40 hover:shadow-xl"
                >
                  {saving ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Saving…
                    </>
                  ) : (
                    <>
                      <Save className="w-5 h-5" />
                      Save Project
                    </>
                  )}
                </Button>
              </motion.div>
            </div>
          )}
        </div>
      </div>
    </motion.section>
  );
}
