import { useState, useEffect } from "react";
import { BookmarkPlus, FolderPlus, Loader2, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { fetchProjects, createProject, saveFieldToProject } from "@/lib/projectsApi";
import type { Project, ProjectField } from "@/types/project";

interface SaveToProjectDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  field: ProjectField;
  data: object;
  fieldLabel: string;
}

export default function SaveToProjectDialog({
  open,
  onOpenChange,
  field,
  data,
  fieldLabel,
}: SaveToProjectDialogProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [mode, setMode] = useState<"pick" | "new">("pick");
  const [savedTo, setSavedTo] = useState<string | null>(null);

  useEffect(() => {
    if (!open || !user) return;
    setLoading(true);
    setSavedTo(null);
    setMode("pick");
    setNewTitle("");
    fetchProjects(user.id)
      .then(setProjects)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [open, user]);

  const handleSaveTo = async (projectId: string, projectTitle: string) => {
    setSaving(true);
    try {
      await saveFieldToProject(projectId, field, data);
      setSavedTo(projectId);
      toast({ title: `${fieldLabel} saved to "${projectTitle}"` });
      setTimeout(() => onOpenChange(false), 800);
    } catch (e: any) {
      toast({ title: "Save failed", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const handleCreateAndSave = async () => {
    if (!newTitle.trim() || !user) return;
    setSaving(true);
    try {
      const project = await createProject(user.id, newTitle.trim());
      await saveFieldToProject(project.id, field, data);
      setSavedTo(project.id);
      toast({ title: `${fieldLabel} saved to new project "${project.title}"` });
      setTimeout(() => onOpenChange(false), 800);
    } catch (e: any) {
      toast({ title: "Save failed", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border text-foreground max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-foreground">
            <BookmarkPlus className="w-5 h-5 text-primary" />
            Save {fieldLabel} to Project
          </DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Save this generated result to one of your projects.
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
          </div>
        ) : (
          <div className="space-y-4 mt-2">
            {/* Toggle */}
            <div className="flex rounded-lg border border-border overflow-hidden">
              <button
                onClick={() => setMode("pick")}
                className={`flex-1 py-2 text-sm font-medium transition-colors ${
                  mode === "pick"
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-muted-foreground hover:text-foreground"
                }`}
              >
                Existing Project
              </button>
              <button
                onClick={() => setMode("new")}
                className={`flex-1 py-2 text-sm font-medium transition-colors ${
                  mode === "new"
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-muted-foreground hover:text-foreground"
                }`}
              >
                New Project
              </button>
            </div>

            {mode === "pick" ? (
              projects.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground text-sm">
                  <p>No projects yet.</p>
                  <button
                    onClick={() => setMode("new")}
                    className="text-primary hover:underline mt-1"
                  >
                    Create your first project
                  </button>
                </div>
              ) : (
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {projects.map((p) => (
                    <button
                      key={p.id}
                      disabled={saving}
                      onClick={() => handleSaveTo(p.id, p.title)}
                      data-testid={`project-option-${p.id}`}
                      className="w-full flex items-center justify-between px-4 py-3 rounded-lg border border-border bg-secondary/50 hover:bg-secondary hover:border-primary/50 transition-all text-left disabled:opacity-50"
                    >
                      <span className="font-medium text-sm text-foreground truncate">{p.title}</span>
                      {savedTo === p.id ? (
                        <Check className="w-4 h-4 text-green-500 shrink-0" />
                      ) : saving ? (
                        <Loader2 className="w-4 h-4 animate-spin text-muted-foreground shrink-0" />
                      ) : null}
                    </button>
                  ))}
                </div>
              )
            ) : (
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <Label className="text-foreground text-sm">Project Title</Label>
                  <Input
                    data-testid="input-new-project-title"
                    placeholder="My Awesome Roblox Game"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleCreateAndSave()}
                    className="bg-input border-border text-foreground placeholder:text-muted-foreground"
                  />
                </div>
                <Button
                  data-testid="button-create-save-project"
                  onClick={handleCreateAndSave}
                  disabled={!newTitle.trim() || saving}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground gap-2"
                >
                  {saving ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <FolderPlus className="w-4 h-4" />
                  )}
                  Create & Save
                </Button>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
