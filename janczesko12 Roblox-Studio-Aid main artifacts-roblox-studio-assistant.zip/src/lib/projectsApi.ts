/**
 * Run this SQL in your Supabase SQL Editor to create / update the projects table:
 *
 * create table if not exists projects (
 *   id uuid default gen_random_uuid() primary key,
 *   user_id uuid references auth.users(id) on delete cascade not null,
 *   title text not null,
 *   is_favorite boolean default false not null,
 *   game_idea jsonb,
 *   quest jsonb,
 *   npc jsonb,
 *   gamepass jsonb,
 *   building jsonb,
 *   lua_script jsonb,
 *   created_at timestamptz default now() not null,
 *   updated_at timestamptz default now() not null
 * );
 *
 * -- If you already have the table, just add the column:
 * alter table projects add column if not exists is_favorite boolean default false not null;
 *
 * alter table projects enable row level security;
 *
 * create policy "Users can manage their own projects"
 *   on projects for all
 *   using (auth.uid() = user_id)
 *   with check (auth.uid() = user_id);
 */

import { supabase } from "@/lib/supabase";
import type { Project, ProjectField } from "@/types/project";

function client() {
  if (!supabase) throw new Error("Supabase is not configured.");
  return supabase;
}

export async function fetchProjects(userId: string): Promise<Project[]> {
  const { data, error } = await client()
    .from("projects")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data as Project[];
}

export async function createProject(userId: string, title: string): Promise<Project> {
  const { data, error } = await client()
    .from("projects")
    .insert({ user_id: userId, title })
    .select()
    .single();
  if (error) throw error;
  return data as Project;
}

export async function updateProjectTitle(id: string, title: string): Promise<void> {
  const { error } = await client()
    .from("projects")
    .update({ title, updated_at: new Date().toISOString() })
    .eq("id", id);
  if (error) throw error;
}

export async function saveFieldToProject(
  projectId: string,
  field: ProjectField,
  value: object
): Promise<void> {
  const { error } = await client()
    .from("projects")
    .update({ [field]: value, updated_at: new Date().toISOString() })
    .eq("id", projectId);
  if (error) throw error;
}

export async function saveFullProject(
  userId: string,
  title: string,
  fields: {
    game_idea?: object | null;
    quest?: object | null;
    npc?: object | null;
    gamepass?: object | null;
    building?: object | null;
    lua_script?: object | null;
  }
): Promise<Project> {
  const { data, error } = await client()
    .from("projects")
    .insert({ user_id: userId, title, is_favorite: false, ...fields })
    .select()
    .single();
  if (error) throw error;
  return data as Project;
}

export async function favoriteProject(id: string, is_favorite: boolean): Promise<void> {
  const { error } = await client()
    .from("projects")
    .update({ is_favorite, updated_at: new Date().toISOString() })
    .eq("id", id);
  if (error) throw error;
}

export async function duplicateProject(project: Project, userId: string): Promise<Project> {
  const { id, created_at, updated_at, ...rest } = project;
  const { data, error } = await client()
    .from("projects")
    .insert({
      ...rest,
      user_id: userId,
      title: `${project.title} (Copy)`,
      is_favorite: false,
    })
    .select()
    .single();
  if (error) throw error;
  return data as Project;
}

export async function deleteProject(id: string): Promise<void> {
  const { error } = await client().from("projects").delete().eq("id", id);
  if (error) throw error;
}
