import { useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Footer from "@/components/Footer";
import GeneratorCard from "@/components/GeneratorCard";
import LuaCard from "@/components/LuaCard";
import SaveProjectSection from "@/components/SaveProjectSection";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Gamepad2, Sword, Bot, Gem, Building2, Zap, Loader2,
  Gamepad, ChevronDown,
} from "lucide-react";

// ─── DATA POOLS ────────────────────────────────────────────────────────────────

const gameIdeasData = {
  titles: ["Neon Dungeon Crawler", "Sky Fortress Battle", "Zombie City Escape", "Underwater Kingdom", "Robot Factory Tycoon", "Dragon Tamer Simulator", "Time Warp Racing", "Ghost Town Mystery", "Ninja Obstacle Course", "Space Colony Builder", "Pirate Treasure Hunt", "Wizard School Roleplay", "Monster Capture Arena", "Cyber Heist", "Medieval Kingdom Wars", "Jungle Expedition", "Arctic Survival", "Haunted Mansion Horror", "Car Dealership Tycoon", "Superhero Training Camp"],
  genres: ["Adventure", "Tycoon", "Simulator", "Horror", "RPG", "Racing", "Battle Royale", "Puzzle", "Tower Defense", "Roleplay"],
  mechanics: ["Resource gathering", "Team-based combat", "Base building", "Boss fights", "Speed running", "Crafting system", "Territory control", "Stealth missions", "Economy system", "Exploration"],
  twists: ["Reverse gravity zones", "Time loop mechanic", "Day/night cycle changes gameplay", "Players can betray teammates", "Random map generation", "Physics-based destruction", "Multiple game modes in one", "Player-built level sharing", "Cross-round progression", "Hidden lore collectibles"]
};

const questsData = {
  names: ["The Lost Artifact", "Dungeon of Shadows", "Protect the Village", "Race to the Summit", "The Traitor's Path", "Gather the Crystals", "Defeat the Dragon King", "Escape the Maze", "Merchant's Dilemma", "The Hidden Temple", "Bounty: Iron Wolf", "Supply Run", "The Ancient Prophecy", "Tower Siege", "Code of the Ancients"],
  objectives: ["Defeat 10 enemies", "Collect 5 rare items", "Reach the top of the tower", "Deliver the package safely", "Survive for 5 minutes", "Find the hidden chest", "Escort the NPC to safety", "Solve the three riddles", "Build a defensive wall", "Catch the spy"],
  rewards: ["500 Gold + Rare Sword", "2x EXP Boost", "Legendary Armor Set", "Exclusive Title", "Special Mount", "100 Gems + Badge", "VIP Access Pass", "Custom Emote Unlock", "50 Robux equivalent items", "Secret Area Access"],
  difficulties: ["Easy", "Medium", "Hard", "Epic"]
};

const npcsData = {
  names: ["Old Man Ezra", "Captain Vex", "Mira the Healer", "The Merchant", "Shadow Guard", "Chef Bornak", "Wizard Torlen", "Zeta-9 (Robot)", "Princess Lyra", "Corrupt Sheriff", "Goblin Trader", "Knight Commander", "The Oracle", "Bandit King Rook", "Doc Sparks"],
  roles: ["Quest Giver", "Merchant", "Enemy Boss", "Ally", "Tutorial Guide", "Secret NPC", "Mini-boss", "Mysterious Stranger"],
  personalities: ["Wise and cryptic", "Aggressive and impatient", "Cheerful and helpful", "Greedy but useful", "Cowardly but knowledgeable", "Noble and honorable", "Cunning and manipulative", "Loyal to the player"],
  dialogues: ["'You there! I've been waiting for a hero like you...'", "'Don't trust anyone in this town, especially me.'", "'I'll sell you anything... for the right price.'", "'The ancient texts speak of one who would come...'", "'Get out of my way before I make you regret it!'", "'Please, you have to help! They took everything!'", "'Psst... I know a secret passage. It'll cost ya.'"]
};

const gamepassesData = {
  names: ["VIP Access", "2x Speed Boost", "Double XP", "Unlimited Lives", "Premium Starter Pack", "God Mode Trial", "Rainbow Trail", "Build Master", "Infinite Currency", "Secret Weapons Pack", "Auto-Farm Bot", "Boss Rush Access", "Legendary Pet Bundle", "Custom Chat Color", "Exclusive Map Access"],
  prices: [99, 149, 199, 249, 299, 349, 499, 599, 699, 799, 999, 1499, 1999, 2499, 4999],
  perks: ["2x coin earnings", "Exclusive VIP area access", "Custom name color", "Special spawn animation", "Bonus starting items", "Unique chat badge", "Early access to new maps", "No respawn cooldown", "Extra inventory slots", "Daily bonus rewards", "Exclusive cosmetic items", "Priority server queue", "Special abilities unlocked", "Auto-collect feature", "Permanent XP multiplier"],
  types: ["Starter", "Premium", "Ultimate"]
};

const buildingsData = {
  names: ["Wizard's Tower", "Underground Bunker", "Sky Pirate Airship", "Haunted Mansion", "Robot Factory", "Crystal Cavern", "Medieval Tavern", "Futuristic Lab", "Tropical Beach House", "Ancient Ruins Temple", "Volcanic Fortress", "Ice Palace", "Treehouse Village", "Space Station Hub", "Underwater Base"],
  styles: ["Medieval", "Sci-Fi", "Fantasy", "Horror", "Modern", "Tropical", "Industrial", "Ancient", "Steampunk", "Cyberpunk"],
  features: ["Secret underground room", "Trapdoors and hidden passages", "Working drawbridge", "Interior lighting system", "Rooftop garden", "Animated machinery", "Custom NPC placement spots", "Modular expansion design", "Parkour obstacle elements", "Decorative murals", "Functional doors and windows", "Water features/moat", "Defensive turret spots", "Multi-level interior", "Glowing accent materials"],
  sizes: ["Small (20x20)", "Medium (50x50)", "Large (100x100)", "Mega (200x200+)"]
};

const luaScripts = [
  {
    title: "Give Player Tool on Touch",
    code: `local tool = game.ServerStorage.Tool:Clone()

game.Workspace.Part.Touched:Connect(function(hit)
    local player = game.Players:GetPlayerFromCharacter(hit.Parent)
    if player then
        tool:Clone().Parent = player.Backpack
    end
end)`,
  },
  {
    title: "Leaderboard with Points",
    code: `game.Players.PlayerAdded:Connect(function(player)
    local leaderstats = Instance.new("Folder")
    leaderstats.Name = "leaderstats"
    leaderstats.Parent = player

    local points = Instance.new("IntValue")
    points.Name = "Points"
    points.Value = 0
    points.Parent = leaderstats
end)`,
  },
  {
    title: "Teleport Player on Touch",
    code: `local destination = Vector3.new(0, 10, 0)

script.Parent.Touched:Connect(function(hit)
    local character = hit.Parent
    local humanoid = character:FindFirstChild("Humanoid")
    if humanoid then
        character:MoveTo(destination)
    end
end)`,
  },
  {
    title: "Day/Night Cycle",
    code: `local lighting = game:GetService("Lighting")
local cycleTime = 60

while true do
    for hour = 0, 24, 0.1 do
        lighting.ClockTime = hour
        task.wait(cycleTime / 240)
    end
end`,
  },
  {
    title: "Kill Brick",
    code: `script.Parent.Touched:Connect(function(hit)
    local humanoid = hit.Parent:FindFirstChild("Humanoid")
    if humanoid then
        humanoid.Health = 0
    end
end)`,
  },
  {
    title: "Sprint Script (LocalScript)",
    code: `local UIS = game:GetService("UserInputService")
local character = game.Players.LocalPlayer.Character
local humanoid = character:WaitForChild("Humanoid")

UIS.InputBegan:Connect(function(input)
    if input.KeyCode == Enum.KeyCode.LeftShift then
        humanoid.WalkSpeed = 30
    end
end)

UIS.InputEnded:Connect(function(input)
    if input.KeyCode == Enum.KeyCode.LeftShift then
        humanoid.WalkSpeed = 16
    end
end)`,
  },
];

// ─── GENERATOR HELPERS ─────────────────────────────────────────────────────────

const pickRandom = (arr: any[]) => arr[Math.floor(Math.random() * arr.length)];
const pickMultiple = (arr: any[], count: number) => {
  const shuffled = [...arr].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
};

const makeGameIdea = () => ({
  Title: pickRandom(gameIdeasData.titles),
  Genre: pickRandom(gameIdeasData.genres),
  Mechanic: pickRandom(gameIdeasData.mechanics),
  Twist: pickRandom(gameIdeasData.twists),
});
const makeQuest = () => ({
  Name: pickRandom(questsData.names),
  Objective: pickRandom(questsData.objectives),
  Reward: pickRandom(questsData.rewards),
  Difficulty: pickRandom(questsData.difficulties),
});
const makeNpc = () => ({
  Name: pickRandom(npcsData.names),
  Role: pickRandom(npcsData.roles),
  Personality: pickRandom(npcsData.personalities),
  Dialogue: pickRandom(npcsData.dialogues),
});
const makeGamepass = () => ({
  Name: pickRandom(gamepassesData.names),
  Type: pickRandom(gamepassesData.types),
  Price: pickRandom(gamepassesData.prices),
  Perks: pickMultiple(gamepassesData.perks, 3),
});
const makeBuilding = () => ({
  Name: pickRandom(buildingsData.names),
  Style: pickRandom(buildingsData.styles),
  Size: pickRandom(buildingsData.sizes),
  Features: pickMultiple(buildingsData.features, 3),
});
const makeLua = () => luaScripts[Math.floor(Math.random() * luaScripts.length)];

// ─── HOME ──────────────────────────────────────────────────────────────────────

export default function Home() {
  const [, setLocation] = useLocation();
  const [generating, setGenerating] = useState(false);
  const [forced, setForced] = useState<Record<string, any>>({});
  const [results, setResults] = useState({
    game_idea: null as any,
    quest:     null as any,
    npc:       null as any,
    gamepass:  null as any,
    building:  null as any,
    lua_script: null as any,
  });

  const setField = (field: keyof typeof results) => (value: any) =>
    setResults((r) => ({ ...r, [field]: value }));

  const handleGenerateAll = async () => {
    setGenerating(true);
    await new Promise((r) => setTimeout(r, 600));
    const all = {
      game_idea:  makeGameIdea(),
      quest:      makeQuest(),
      npc:        makeNpc(),
      gamepass:   makeGamepass(),
      building:   makeBuilding(),
      lua_script: makeLua(),
    };
    setForced(all);
    setResults(all);
    setGenerating(false);
    // scroll to generators
    setTimeout(() => {
      document.getElementById("game-ideas")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 100);
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <Navbar />

      <main className="flex-1">
        <Hero />

        {/* ── Generate Full Game Banner ── */}
        <section className="border-y border-border/50 bg-gradient-to-r from-primary/5 via-background to-primary/5">
          <div className="container mx-auto px-4 py-8">
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="flex flex-col md:flex-row items-center justify-between gap-6"
            >
              <div className="text-center md:text-left">
                <div className="flex items-center justify-center md:justify-start gap-2 mb-1">
                  <Zap className="w-5 h-5 text-primary" />
                  <h2 className="text-xl font-bold text-foreground">Generate Full Game</h2>
                </div>
                <p className="text-muted-foreground text-sm max-w-md">
                  Populate all 6 generators at once — game idea, quest, NPC, gamepass, building &amp; Lua script — then save with one click.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-3">
                <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
                  <Button
                    data-testid="button-generate-all"
                    onClick={handleGenerateAll}
                    disabled={generating}
                    size="lg"
                    className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold px-8 gap-3 shadow-lg shadow-primary/20 text-base"
                  >
                    {generating ? (
                      <><Loader2 className="w-5 h-5 animate-spin" /> Generating…</>
                    ) : (
                      <><Zap className="w-5 h-5" /> Generate Full Game</>
                    )}
                  </Button>
                </motion.div>
                <button
                  onClick={() => document.getElementById("game-ideas")?.scrollIntoView({ behavior: "smooth" })}
                  className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  Or use generators individually
                  <ChevronDown className="w-4 h-4" />
                </button>
              </div>
            </motion.div>

            {/* Progress indicator after generate all */}
            <AnimatePresence>
              {results.game_idea && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3, delay: 0.1 }}
                  className="mt-4 flex flex-wrap gap-2"
                >
                  {[
                    { key: "game_idea", label: "Game Idea", Icon: Gamepad2 },
                    { key: "quest",     label: "Quest",     Icon: Sword    },
                    { key: "npc",       label: "NPC",       Icon: Bot      },
                    { key: "gamepass",  label: "Gamepass",  Icon: Gem      },
                    { key: "building",  label: "Building",  Icon: Building2},
                    { key: "lua_script",label: "Lua Script",Icon: Gamepad  },
                  ].map(({ key, label, Icon }) => (
                    <Badge
                      key={key}
                      variant="outline"
                      className={`gap-1.5 text-xs transition-all ${
                        (results as any)[key]
                          ? "border-primary/40 bg-primary/10 text-primary"
                          : "border-border/40 text-muted-foreground/40"
                      }`}
                    >
                      <Icon className="w-3 h-3" />
                      {label}
                    </Badge>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </section>

        <div className="container mx-auto px-4 py-16 space-y-24">

          {/* Game Ideas */}
          <GeneratorCard
            id="game-ideas"
            title="Game Idea Generator"
            icon={<Gamepad2 />}
            projectField="game_idea"
            fieldLabel="Game Idea"
            onResultChange={setField("game_idea")}
            externalResult={forced.game_idea}
            delay={0.1}
            generateFunction={makeGameIdea}
            renderResult={(data) => (
              <div className="space-y-4">
                <h3 className="text-2xl font-bold text-foreground mb-4">{data.Title}</h3>
                <div className="grid grid-cols-1 gap-2">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                    <span className="font-semibold text-muted-foreground w-24">Genre:</span>
                    <Badge variant="outline" className="w-fit">{data.Genre}</Badge>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                    <span className="font-semibold text-muted-foreground w-24">Core:</span>
                    <span className="text-foreground">{data.Mechanic}</span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                    <span className="font-semibold text-muted-foreground w-24">Twist:</span>
                    <span className="text-primary font-medium">{data.Twist}</span>
                  </div>
                </div>
              </div>
            )}
          />

          {/* Quests */}
          <GeneratorCard
            id="quests"
            title="Quest Generator"
            icon={<Sword />}
            projectField="quest"
            fieldLabel="Quest"
            onResultChange={setField("quest")}
            externalResult={forced.quest}
            delay={0.2}
            generateFunction={makeQuest}
            renderResult={(data) => {
              const difficultyColors: Record<string, string> = {
                "Easy": "bg-green-500/10 text-green-500 border-green-500/20",
                "Medium": "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
                "Hard": "bg-orange-500/10 text-orange-500 border-orange-500/20",
                "Epic": "bg-red-500/10 text-red-500 border-red-500/20"
              };
              return (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-2xl font-bold text-foreground">{data.Name}</h3>
                    <Badge variant="outline" className={difficultyColors[data.Difficulty]}>
                      {data.Difficulty}
                    </Badge>
                  </div>
                  <div className="space-y-3">
                    <div className="bg-background/80 p-3 rounded-md border border-border">
                      <p className="text-sm font-semibold text-muted-foreground mb-1">Objective</p>
                      <p className="text-foreground">{data.Objective}</p>
                    </div>
                    <div className="bg-background/80 p-3 rounded-md border border-border">
                      <p className="text-sm font-semibold text-muted-foreground mb-1">Reward</p>
                      <p className="text-primary font-medium">{data.Reward}</p>
                    </div>
                  </div>
                </div>
              );
            }}
          />

          {/* NPCs */}
          <GeneratorCard
            id="npcs"
            title="NPC Generator"
            icon={<Bot />}
            projectField="npc"
            fieldLabel="NPC"
            onResultChange={setField("npc")}
            externalResult={forced.npc}
            delay={0.3}
            generateFunction={makeNpc}
            renderResult={(data) => (
              <div className="space-y-4">
                <div className="flex items-center gap-3 mb-4">
                  <h3 className="text-2xl font-bold text-foreground">{data.Name}</h3>
                  <Badge>{data.Role}</Badge>
                </div>
                <div className="space-y-4">
                  <div>
                    <span className="font-semibold text-muted-foreground block mb-1">Personality</span>
                    <span className="text-foreground">{data.Personality}</span>
                  </div>
                  <div className="relative">
                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary/50 rounded-l-sm" />
                    <div className="bg-muted/30 p-4 pl-6 rounded-md rounded-l-none italic text-foreground/90">
                      {data.Dialogue}
                    </div>
                  </div>
                </div>
              </div>
            )}
          />

          {/* Gamepasses */}
          <GeneratorCard
            id="gamepasses"
            title="Gamepass Generator"
            icon={<Gem />}
            projectField="gamepass"
            fieldLabel="Gamepass"
            onResultChange={setField("gamepass")}
            externalResult={forced.gamepass}
            delay={0.4}
            generateFunction={makeGamepass}
            renderResult={(data) => (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
                  <div className="flex items-center gap-3">
                    <h3 className="text-2xl font-bold text-foreground">{data.Name}</h3>
                    <Badge variant="secondary">{data.Type}</Badge>
                  </div>
                  <div className="flex items-center gap-1 bg-green-500/10 text-green-500 px-3 py-1 rounded-full border border-green-500/20 font-bold">
                    <span className="text-sm">R$</span> {data.Price}
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold text-muted-foreground mb-3 text-sm uppercase tracking-wider">Included Perks</h4>
                  <ul className="space-y-2">
                    {data.Perks.map((perk: string, i: number) => (
                      <li key={i} className="flex items-start gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                        <span className="text-foreground">{perk}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          />

          {/* Buildings */}
          <GeneratorCard
            id="buildings"
            title="Building Generator"
            icon={<Building2 />}
            projectField="building"
            fieldLabel="Building"
            onResultChange={setField("building")}
            externalResult={forced.building}
            delay={0.5}
            generateFunction={makeBuilding}
            renderResult={(data) => (
              <div className="space-y-4">
                <h3 className="text-2xl font-bold text-foreground mb-4">{data.Name}</h3>
                <div className="flex flex-wrap gap-2 mb-6">
                  <Badge variant="outline" className="bg-background">Style: {data.Style}</Badge>
                  <Badge variant="outline" className="bg-background">Size: {data.Size}</Badge>
                </div>
                <div className="bg-background/50 rounded-md border border-border p-4">
                  <h4 className="font-semibold text-muted-foreground mb-3 text-sm">Key Features</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {data.Features.map((feature: string, i: number) => (
                      <div key={i} className="bg-muted/30 p-3 rounded-md text-sm border border-border/50 text-foreground">
                        {feature}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          />

          {/* Lua Helper */}
          <LuaCard
            id="lua-helper"
            scripts={luaScripts}
            delay={0.6}
            onResultChange={setField("lua_script")}
            externalResult={forced.lua_script}
          />

          {/* Save Project */}
          <SaveProjectSection results={results} />

        </div>
      </main>

      <Footer />
    </div>
  );
}
