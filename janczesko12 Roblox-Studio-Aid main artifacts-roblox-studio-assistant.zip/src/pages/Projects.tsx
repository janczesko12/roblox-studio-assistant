import { useState, useEffect, useMemo } from "react";
import { useLocation } from "wouter";
import {
  Search, Trash2, Pencil, Check, X, FolderOpen, Plus,
  Gamepad2, Sword, Bot, Gem, Building2, Code2,
  Loader2, ArrowUpDown, Star, Copy, ChevronDown, ChevronUp,
  Calendar, Filter,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";
import {
  fetchProjects, deleteProject, updateProjectTitle,
  favoriteProject, duplicateProject,
} from "@/lib/projectsApi";
import { PROJECT_FIELDS } from "@/types/project";
import type { Project } from "@/types/project";

// ─── Genre theme map ───────────────────────────────────────────────────────────
const GENRE_THEMES: Record<string, { grad: string; text: string; emoji: string }> = {
  "Adventure":     { grad: "from-blue-900 via-blue-950 to-[#0a0a14]",    text: "text-blue-400",   emoji: "🗺️"  },
  "Tycoon":        { grad: "from-emerald-900 via-emerald-950 to-[#0a0a14]",text: "text-emerald-400",emoji: "💰" },
  "Simulator":     { grad: "from-cyan-900 via-cyan-950 to-[#0a0a14]",    text: "text-cyan-400",   emoji: "🔬"  },
  "Horror":        { grad: "from-red-950 via-zinc-900 to-[#0a0a14]",     text: "text-red-400",    emoji: "👻"  },
  "RPG":           { grad: "from-purple-900 via-purple-950 to-[#0a0a14]",text: "text-purple-400", emoji: "⚔️" },
  "Racing":        { grad: "from-yellow-900 via-zinc-900 to-[#0a0a14]",  text: "text-yellow-400", emoji: "🏎️" },
  "Battle Royale": { grad: "from-orange-900 via-zinc-900 to-[#0a0a14]",  text: "text-orange-400", emoji: "🎯" },
  "Puzzle":        { grad: "from-teal-900 via-teal-950 to-[#0a0a14]",    text: "text-teal-400",   emoji: "🧩"  },
  "Tower Defense": { grad: "from-indigo-900 via-indigo-950 to-[#0a0a14]",text: "text-indigo-400", emoji: "🏰"  },
  "Roleplay":      { grad: "from-pink-900 via-pink-950 to-[#0a0a14]",    text: "text-pink-400",   emoji: "🎭"  },
};
const defaultTheme = { grad: "from-zinc-800 via-zinc-900 to-[#0a0a14]", text: "text-zinc-400", emoji: "🎮" };

function getTheme(genre?: string) {
  return genre ? (GENRE_THEMES[genre] ?? defaultTheme) : defaultTheme;
}

// ─── Field icons ────────────────────────────────────────────────────────────
const FIELD_ICONS: Record<string, React.ReactNode> = {
  game_idea:  <Gamepad2 className="w-3 h-3" />,
  quest:      <Sword className="w-3 h-3" />,
  npc:        <Bot className="w-3 h-3" />,
  gamepass:   <Gem className="w-3 h-3" />,
  building:   <Building2 className="w-3 h-3" />,
  lua_script: <Code2 className="w-3 h-3" />,
};

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-US", {
    month: "short", day: "numeric", year: "numeric",
  });
}

// ─── Thumbnail ───────────────────────────────────────────────────────────────
function ProjectThumbnail({ project }: { project: Project }) {
  const genre = project.game_idea?.Genre;
  const theme = getTheme(genre);
  const filledCount = PROJECT_FIELDS.filter((f) => project[f.key] !== null).length;

  return (
    <div className={`relative h-36 bg-gradient-to-br ${theme.grad} overflow-hidden flex items-center justify-center`}>
      <div className="absolute inset-0 opacity-10"
        style={{ backgroundImage: "radial-gradient(circle at 20% 80%, rgba(255,255,255,0.15) 0%, transparent 60%)" }} />
      <span className="text-5xl select-none">{theme.emoji}</span>
      <div className="absolute top-3 right-3">
        <span className={`text-xs font-bold ${theme.text} bg-black/40 backdrop-blur px-2 py-0.5 rounded-full`}>
          {filledCount}/6 sections
        </span>
      </div>
      {genre && (
        <div className="absolute bottom-3 left-3">
          <span className={`text-xs font-semibold ${theme.text} bg-black/50 backdrop-blur px-2 py-0.5 rounded`}>
            {genre}
          </span>
        </div>
      )}
    </div>
  );
}

// ─── Project Card ────────────────────────────────────────────────────────────
function ProjectCard({
  project,
  onDeleted,
  onTitleUpdated,
  onFavoriteToggled,
  onDuplicated,
}: {
  project: Project;
  onDeleted: (id: string) => void;
  onTitleUpdated: (id: string, title: string) => void;
  onFavoriteToggled: (id: string, val: boolean) => void;
  onDuplicated: (p: Project) => void;
}) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [expanded, setExpanded] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(project.title);
  const [saving, setSaving] = useState(false);
  const [favLoading, setFavLoading] = useState(false);
  const [dupLoading, setDupLoading] = useState(false);

  const filledFields = PROJECT_FIELDS.filter((f) => project[f.key] !== null && project[f.key] !== undefined);

  const handleSaveTitle = async () => {
    if (!editTitle.trim() || editTitle === project.title) { setEditing(false); return; }
    setSaving(true);
    try {
      await updateProjectTitle(project.id, editTitle.trim());
      onTitleUpdated(project.id, editTitle.trim());
      toast({ title: "Title updated" });
    } catch (e: any) {
      toast({ title: "Failed to update", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
      setEditing(false);
    }
  };

  const handleDelete = async () => {
    try {
      await deleteProject(project.id);
      onDeleted(project.id);
      toast({ title: "Project deleted" });
    } catch (e: any) {
      toast({ title: "Failed to delete", description: e.message, variant: "destructive" });
    }
  };

  const handleFavorite = async () => {
    setFavLoading(true);
    try {
      const next = !project.is_favorite;
      await favoriteProject(project.id, next);
      onFavoriteToggled(project.id, next);
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally {
      setFavLoading(false);
    }
  };

  const handleDuplicate = async () => {
    if (!user) return;
    setDupLoading(true);
    try {
      const copy = await duplicateProject(project, user.id);
      onDuplicated(copy);
      toast({ title: "Project duplicated", description: `"${copy.title}" created` });
    } catch (e: any) {
      toast({ title: "Failed to duplicate", description: e.message, variant: "destructive" });
    } finally {
      setDupLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.25 }}
      layout
      className="flex flex-col rounded-xl border border-border bg-card overflow-hidden hover:border-primary/30 transition-all duration-200 shadow-md hover:shadow-primary/5 hover:shadow-lg"
    >
      {/* Thumbnail */}
      <ProjectThumbnail project={project} />

      {/* Body */}
      <div className="flex flex-col flex-1 p-4 gap-3">
        {/* Title row */}
        <div className="flex items-start gap-2">
          <div className="flex-1 min-w-0">
            {editing ? (
              <div className="flex items-center gap-1.5">
                <Input
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") handleSaveTitle(); if (e.key === "Escape") setEditing(false); }}
                  className="h-7 text-sm font-bold bg-input border-border text-foreground"
                  autoFocus
                />
                <Button size="icon" variant="ghost" className="h-7 w-7 text-green-500" onClick={handleSaveTitle} disabled={saving}>
                  {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />}
                </Button>
                <Button size="icon" variant="ghost" className="h-7 w-7 text-muted-foreground" onClick={() => { setEditing(false); setEditTitle(project.title); }}>
                  <X className="w-3 h-3" />
                </Button>
              </div>
            ) : (
              <h3 className="font-bold text-base text-foreground leading-tight truncate">{project.title}</h3>
            )}
          </div>
          {/* Favorite button */}
          <button
            onClick={handleFavorite}
            disabled={favLoading}
            className={`shrink-0 p-1 rounded transition-colors ${project.is_favorite ? "text-yellow-400" : "text-muted-foreground hover:text-yellow-400"}`}
            title={project.is_favorite ? "Unfavorite" : "Favorite"}
          >
            {favLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Star className={`w-4 h-4 ${project.is_favorite ? "fill-yellow-400" : ""}`} />}
          </button>
        </div>

        {/* Date */}
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Calendar className="w-3 h-3" />
          {formatDate(project.created_at)}
        </div>

        {/* Game idea preview */}
        {project.game_idea && (
          <div className="bg-background/60 rounded-lg border border-border/50 p-3">
            <p className="text-sm font-semibold text-foreground leading-snug truncate">{project.game_idea.Title}</p>
            <p className="text-xs text-muted-foreground mt-0.5 truncate">{project.game_idea.Genre} · {project.game_idea.Mechanic}</p>
          </div>
        )}

        {/* Section badges */}
        {filledFields.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {filledFields.map((f) => (
              <Badge key={f.key} variant="outline" className="gap-1 text-xs py-0 border-primary/20 text-primary/80 bg-primary/5">
                {FIELD_ICONS[f.key]}
                {f.label}
              </Badge>
            ))}
          </div>
        )}

        {/* Expand content */}
        {filledFields.length > 0 && (
          <button
            onClick={() => setExpanded(!expanded)}
            className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors mt-1"
          >
            {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            {expanded ? "Hide" : "View"} full content
          </button>
        )}

        <AnimatePresence>
          {expanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              <div className="space-y-3 pt-1">
                {filledFields.map((f) => (
                  <div key={f.key} className="rounded-lg border border-border bg-background/50 p-3">
                    <div className="flex items-center gap-1.5 mb-2">
                      <span className="text-primary">{FIELD_ICONS[f.key]}</span>
                      <span className="font-semibold text-xs text-foreground uppercase tracking-wide">{f.label}</span>
                    </div>
                    {f.key === "lua_script" ? (
                      <div>
                        <p className="text-sm font-semibold text-foreground mb-1">{project[f.key]?.title}</p>
                        <pre className="text-xs font-mono text-muted-foreground bg-[#0d0d0d] border border-border border-l-4 border-l-primary rounded p-2 overflow-x-auto whitespace-pre">
                          <code>{project[f.key]?.code}</code>
                        </pre>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        {Object.entries(project[f.key] ?? {}).map(([k, v]) => (
                          <div key={k} className="flex gap-2 text-xs">
                            <span className="text-muted-foreground capitalize shrink-0 w-20">{k}:</span>
                            <span className="text-foreground font-medium">{Array.isArray(v) ? (v as string[]).join(", ") : String(v)}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Actions */}
        <div className="flex items-center gap-1.5 mt-auto pt-2 border-t border-border/50">
          <Button
            size="sm"
            variant="ghost"
            className="h-8 text-xs text-muted-foreground hover:text-foreground gap-1.5 px-2"
            onClick={() => { setEditing(true); setEditTitle(project.title); }}
          >
            <Pencil className="w-3.5 h-3.5" />
            Edit
          </Button>

          <Button
            size="sm"
            variant="ghost"
            className="h-8 text-xs text-muted-foreground hover:text-foreground gap-1.5 px-2"
            onClick={handleDuplicate}
            disabled={dupLoading}
          >
            {dupLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Copy className="w-3.5 h-3.5" />}
            Duplicate
          </Button>

          <div className="ml-auto">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-8 text-xs text-muted-foreground hover:text-primary gap-1.5 px-2"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="bg-card border-border text-foreground">
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete project?</AlertDialogTitle>
                  <AlertDialogDescription className="text-muted-foreground">
                    This will permanently delete <span className="text-foreground font-medium">"{project.title}"</span>. This cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel className="border-border text-foreground hover:bg-secondary">Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDelete} className="bg-primary hover:bg-primary/80 text-primary-foreground">
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// ─── Page ────────────────────────────────────────────────────────────────────
type SortOption = "newest" | "oldest" | "favorites";

export default function Projects() {
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<SortOption>("newest");
  const [genreFilter, setGenreFilter] = useState<string>("all");

  useEffect(() => {
    if (!authLoading && !user) { setLocation("/login"); return; }
    if (!user) return;
    setLoading(true);
    fetchProjects(user.id)
      .then(setProjects)
      .catch((e) => toast({ title: "Failed to load projects", description: e.message, variant: "destructive" }))
      .finally(() => setLoading(false));
  }, [user, authLoading]);

  // Collect all genres from projects
  const genres = useMemo(() => {
    const g = new Set<string>();
    projects.forEach((p) => { if (p.game_idea?.Genre) g.add(p.game_idea.Genre); });
    return Array.from(g).sort();
  }, [projects]);

  const filtered = useMemo(() => {
    let list = [...projects];

    if (search) list = list.filter((p) => p.title.toLowerCase().includes(search.toLowerCase()));
    if (genreFilter !== "all") list = list.filter((p) => p.game_idea?.Genre === genreFilter);

    if (sort === "newest") list.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    else if (sort === "oldest") list.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
    else if (sort === "favorites") list.sort((a, b) => (b.is_favorite ? 1 : 0) - (a.is_favorite ? 1 : 0) || new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    return list;
  }, [projects, search, sort, genreFilter]);

  const handleDeleted = (id: string) => setProjects((p) => p.filter((x) => x.id !== id));
  const handleTitleUpdated = (id: string, title: string) => setProjects((p) => p.map((x) => x.id === id ? { ...x, title } : x));
  const handleFavoriteToggled = (id: string, val: boolean) => setProjects((p) => p.map((x) => x.id === id ? { ...x, is_favorite: val } : x));
  const handleDuplicated = (copy: Project) => setProjects((p) => [copy, ...p]);

  const sortLabel: Record<SortOption, string> = {
    newest: "Newest first",
    oldest: "Oldest first",
    favorites: "Favorites first",
  };

  if (authLoading || (loading && !projects.length)) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      <main className="flex-1 container mx-auto px-4 py-12 max-w-6xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8 flex-wrap gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
              <FolderOpen className="w-8 h-8 text-primary" />
              My Projects
            </h1>
            <p className="text-muted-foreground mt-1">
              {projects.length === 0 ? "No projects yet" : `${projects.length} project${projects.length !== 1 ? "s" : ""}${filtered.length !== projects.length ? ` · ${filtered.length} shown` : ""}`}
            </p>
          </div>
          <Button
            onClick={() => setLocation("/")}
            className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2"
          >
            <Plus className="w-4 h-4" />
            New Project
          </Button>
        </div>

        {/* Controls */}
        {projects.length > 0 && (
          <div className="flex gap-2 mb-6 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search projects…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 bg-input border-border text-foreground placeholder:text-muted-foreground"
              />
            </div>

            {/* Genre filter */}
            {genres.length > 0 && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="border-border text-foreground hover:bg-secondary gap-2">
                    <Filter className="w-4 h-4" />
                    {genreFilter === "all" ? "All Genres" : genreFilter}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-card border-border text-foreground">
                  <DropdownMenuItem onClick={() => setGenreFilter("all")} className="cursor-pointer hover:bg-secondary focus:bg-secondary">
                    All Genres
                  </DropdownMenuItem>
                  <DropdownMenuSeparator className="bg-border" />
                  {genres.map((g) => (
                    <DropdownMenuItem key={g} onClick={() => setGenreFilter(g)} className="cursor-pointer hover:bg-secondary focus:bg-secondary">
                      {getTheme(g).emoji} {g}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            {/* Sort */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="border-border text-foreground hover:bg-secondary gap-2">
                  <ArrowUpDown className="w-4 h-4" />
                  {sortLabel[sort]}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-card border-border text-foreground">
                {(["newest", "oldest", "favorites"] as SortOption[]).map((s) => (
                  <DropdownMenuItem key={s} onClick={() => setSort(s)} className="cursor-pointer hover:bg-secondary focus:bg-secondary">
                    {s === "favorites" && <Star className="w-3.5 h-3.5 mr-1.5 text-yellow-400" />}
                    {sortLabel[s]}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}

        {/* Content */}
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : projects.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <FolderOpen className="w-16 h-16 text-border mb-4" />
            <h2 className="text-xl font-semibold text-foreground mb-2">No projects yet</h2>
            <p className="text-muted-foreground mb-6 max-w-sm">
              Generate ideas on the home page and save them to a project. Or use <strong>Generate Full Game</strong> to create everything at once.
            </p>
            <Button onClick={() => setLocation("/")} className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2">
              <Plus className="w-4 h-4" />
              Start Generating
            </Button>
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <Search className="w-12 h-12 mx-auto mb-3 text-border" />
            <p>No projects match your filters.</p>
            <button onClick={() => { setSearch(""); setGenreFilter("all"); }} className="text-primary text-sm mt-2 hover:underline">
              Clear filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            <AnimatePresence mode="popLayout">
              {filtered.map((project) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  onDeleted={handleDeleted}
                  onTitleUpdated={handleTitleUpdated}
                  onFavoriteToggled={handleFavoriteToggled}
                  onDuplicated={handleDuplicated}
                />
              ))}
            </AnimatePresence>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
